Diary Program
The program is able to insert new records, delete rocords, check old records. 
Everything is stored in a file with the persons name in it. 
When the file does not exists it gets created. 

User Program
User program create user for a company which asks for username, encrypted password, salary in USD, email.
The information is stored in file, created with the user - username, as  a name.
The program is able to print the info about a user.